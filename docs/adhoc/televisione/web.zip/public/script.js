//  Enumerations.swift
const ChannelLiveGuid = {
    raiuno: "Rai 1",
    raidue: "Rai 2",
    raitre: "Rai 3",
    retequattro: "R4_STATION",
    canalecinque: "C5_STATION",
    italiauno: "I1_STATION"
}
const ChannelGuid = {
    raiuno: "rai-1",
    raidue: "rai-2",
    raitre: "rai-3",
    retequattro: "R4",
    canalecinque: "C5",
    italiauno: "I1"
}
function ChannelGuidConverter(from) {
    switch (from) {
    case ChannelLiveGuid.raiuno:
        return ChannelGuid.raiuno;
    case ChannelLiveGuid.raidue:
        return ChannelGuid.raidue;
    case ChannelLiveGuid.raitre:
        return ChannelGuid.raitre;
    case ChannelLiveGuid.retequattro:
        return ChannelGuid.retequattro;
    case ChannelLiveGuid.canalecinque:
        return ChannelGuid.canalecinque;
    case ChannelLiveGuid.italiauno:
        return ChannelGuid.italiauno;
    case ChannelGuid.raiuno:
        return ChannelLiveGuid.raiuno;
    case ChannelGuid.raidue:
        return ChannelLiveGuid.raidue;
    case ChannelGuid.raitre:
        return ChannelLiveGuid.raitre;
    case ChannelGuid.retequattro:
        return ChannelLiveGuid.retequattro;
    case ChannelGuid.canalecinque:
        return ChannelLiveGuid.canalecinque;
    case ChannelGuid.italiauno:
        return ChannelLiveGuid.italiauno;
    }
}
function ChannelGuidToNumber(from) {
    switch (from) {
    case ChannelLiveGuid.raiuno: return 1;
    case ChannelLiveGuid.raidue: return 2;
    case ChannelLiveGuid.raitre: return 3;
    case ChannelLiveGuid.retequattro: return 4;
    case ChannelLiveGuid.canalecinque: return 5;
    case ChannelLiveGuid.italiauno: return 6;
    case ChannelGuid.raiuno: return 1;
    case ChannelGuid.raidue: return 2;
    case ChannelGuid.raitre: return 3;
    case ChannelGuid.retequattro: return 4;
    case ChannelGuid.canalecinque: return 5;
    case ChannelGuid.italiauno: return 6;
    }
}
const NetworkGuid = {
    rai: "Rai",
    mediaset: "Mediaset"
}

//  Channel.swift
class NowPlaying {
    constructor(title, start, end, next) {
        this.title = title; // String
        this.start = start; // String
        this.end = end; // String
        this.next = next; // String
    }
    toCurrentString() {
        if (this.start == null || this.end == null) return null;
        return `${this.start}-${this.end} ${this.title}`;
    }
    toNextString() {
        if (this.start == null || this.end == null) return null;
        return `A Seguire: ${this.next}`;
    }
}
class Channel {
    constructor(name, id, network, symbol="tv.circle") {
        this.id = id; // ChannelGuid
        this.network = network; // NetworkGuid
        this.name = name; // String
        this.symbol = symbol; // String

        this.homepage = null
        this.player = null
        this.info = null
    }
}

//  NetworkHelper.swift
function NetworkHelper(url, cached=true, failure=null, success) {
    success = (typeof success === 'undefined' && typeof cached !== 'boolean') ? cached : success;
    cached = (typeof cached === 'boolean') ? cached : true;
    const request = new Request(url, {
        method: 'GET',
        mode: 'cors',
        cache: (cached == true) ? 'default' : 'reload'
    });
    fetch(request)
        .then(response => response.json())
        .then(json => {
            if (success != null) {
                success(json);
            } else {
                console.log('NetworkHelper: LOG', json);
            }
        })
        .catch((error) => {
            console.error('NetworkHelper: ERROR', error);
            if (failure != null) {
                failure();
            }
            return;
        });
}

//  Model.swift
class Model {
    constructor(root) {
        this.root = root;

        this.raiuno = new Channel("Rai Uno", ChannelGuid.raiuno, NetworkGuid.rai, "1.circle");
            this.raiunoDidChange = () => {};
        this.raidue = new Channel("Rai Due", ChannelGuid.raidue, NetworkGuid.rai, "2.circle");
            this.raidueDidChange = () => {};
        this.raitre = new Channel("Rai Tre", ChannelGuid.raitre, NetworkGuid.rai, "3.circle");
            this.raitreDidChange = () => {};
        this.retequattro = new Channel("Rete 4", ChannelGuid.retequattro, NetworkGuid.mediaset, "4.circle");
            this.retequattroDidChange = () => {};
        this.canalecinque = new Channel("Canale 5", ChannelGuid.canalecinque, NetworkGuid.mediaset, "5.circle");
            this.canalecinqueDidChange = () => {};
        this.italiauno = new Channel("Italia 1", ChannelGuid.italiauno, NetworkGuid.mediaset, "6.circle");
            this.italiaunoDidChange = () => {};

        this.loadStreams();
        this.loadNowPlaying();
    }

    // ChannelGuid
    play(channel) {
        let validRoot = this.root ?? document.body;
        if (validRoot == null) return;
        /// Pause all other streams
        for (const item of this.getAllChannels()) {
            if (item.id != channel) {
                item.player?.pause();
            }
        }
        validRoot.innerHTML = "";
        /// Resume this stream
        let item = this.getChannelByGuid(channel);
        // Player
        if (item.player != null) {
            validRoot.appendChild(item.player);
            if (Boolean(item.player.canPlayType('application/vnd.apple.mpegURL') || item.player.canPlayType('audio/mpegurl')) == false) {
                let poly = videojs(item.player, {
                    autoplay: 'true'
                }); // Video.JS
                poly.play();
            } else {
                item.player.load();
                this.listener = item.player.addEventListener("durationchange", (event) => {
                    if (item.player.seekable.length > 0) {
                        let time = item.player.seekable.end(0);
                        if (time != null) {
                            if (time - item.player.currentTime > 30) item.player.currentTime = time;
                            item.player.removeEventListener("durationchange", this.listener);
                        }
                    }
                });
                item.player.play();
            }
        }
        // Info
        validRoot.appendChild(CreateUserInterface(item, item.info?.toCurrentString(), item.info?.toNextString()));
    }
    updateUserInterface(channel) {
        let uxRoot = document.querySelector("#AGTVux");
        if (uxRoot == null) return;
        let item = this.getChannelByGuid(channel);
        uxRoot.replaceWith(CreateUserInterface(item, item.info?.toCurrentString(), item.info?.toNextString()));
    }
    
    getAllChannels() {
        return [this.raiuno, this.raidue, this.raitre, this.retequattro, this.canalecinque, this.italiauno]
    }

    getChannelByGuid(channel) {
        let channels = this.getAllChannels();
        for (let index in channels) {
            if (channels[index].id == channel) return channels[index];
        }
    }
    conditionalLoad() {
        for (const channel of this.getAllChannels()) {
            if ( (channel.info.end < GetCurrentTime()) || ((channel.info.end.substring(0,2) == "23") && (GetCurrentTime().substring(0,2) != "23")) ) {
                let test = document.createElement("video");
                if (Boolean(test.canPlayType('application/vnd.apple.mpegURL') || test.canPlayType('audio/mpegurl'))) {
                    this.loadStreams();
                }
                this.loadNowPlaying();
                return;
            }
        }
    }

    loadStreams() {
        /// Load Rai Streaming Urls
        NetworkHelper("https://www.rai.it/dl/RaiPlay/2016/PublishingBlock-9a2ff311-fcf0-4539-8f8f-c4fee2a71d58.html?json", (json) => {
            for (const station of json["dirette"]) {
                if (station["channel"] == ChannelLiveGuid.raiuno) {
                    this.raiuno.homepage = station["weblink"];
                    delete(this.raiuno.player);
                    this.raiuno.player = CreateVideoElement(station["video"]["contentUrl"]);
                    this.raiunoDidChange?.();
                } else if (station["channel"] == ChannelLiveGuid.raidue) {
                    this.raidue.homepage = station["weblink"];
                    delete(this.raidue.player);
                    this.raidue.player = CreateVideoElement(station["video"]["contentUrl"]);
                    this.raidueDidChange?.();
                } else if (station["channel"] == ChannelLiveGuid.raitre) {
                    this.raitre.homepage = station["weblink"];
                    delete(this.raitre.player);
                    this.raitre.player = CreateVideoElement(station["video"]["contentUrl"]);
                    this.raitreDidChange?.();
                }
            }
        });
        /// Load Mediaset Streaming Urls
        NetworkHelper("https://feed.entertainment.tv.theplatform.eu/f/PR1GhC/mediaset-prod-all-stations?bycallsign=&range=1-1000&fields=guid,title,thumbnails,mediasetstation$pageUrl,tuningInstruction", (json) => {
            for (const station of json["entries"]) {
                if (station["guid"] == ChannelLiveGuid.canalecinque) {
                    this.canalecinque.homepage = station["mediasetstation$pageUrl"];
                    delete(this.canalecinque.player);
                    this.canalecinque.player = CreateVideoElement(station["tuningInstruction"]["urn:theplatform:tv:location:any"].filter(stream => (stream["format"] == "application/x-mpegURL") && (stream["assetTypes"].includes("geoIT")) && (stream["publicUrls"].length > 0))[0]["publicUrls"][0]);
                    this.canalecinqueDidChange?.();
                } else if (station["guid"] == ChannelLiveGuid.retequattro) {
                    this.retequattro.homepage = station["mediasetstation$pageUrl"];
                    delete(this.retequattro.player);
                    this.retequattro.player = CreateVideoElement(station["tuningInstruction"]["urn:theplatform:tv:location:any"].filter(stream => (stream["format"] == "application/x-mpegURL") && (stream["assetTypes"].includes("geoIT")) && (stream["publicUrls"].length > 0))[0]["publicUrls"][0]);
                    this.retequattroDidChange?.();
                } else if (station["guid"] == ChannelLiveGuid.italiauno) {
                    this.italiauno.homepage = station["mediasetstation$pageUrl"];
                    delete(this.italiauno.player);
                    this.italiauno.player = CreateVideoElement(station["tuningInstruction"]["urn:theplatform:tv:location:any"].filter(stream => (stream["format"] == "application/x-mpegURL") && (stream["assetTypes"].includes("geoIT")) && (stream["publicUrls"].length > 0))[0]["publicUrls"][0]);
                    this.italiaunoDidChange?.();
                }
            }
        });
    }

    loadNowPlaying() {
        /// Load Rai Now Playing Data
        NetworkHelper("https://www.raiplay.it/palinsesto/oraInOnda.json", (json) => {
            for (const station of json["dirette"]) {
                if (station["currentItem"]["name"] != "" && station["nextItem"]["name"] != "") {
                    if (station["channel"] == ChannelLiveGuid.raiuno) {
                        this.raiuno.info = new NowPlaying(station["currentItem"]["name"], station["currentItem"]["timePublished"], station["nextItem"]["timePublished"], station["nextItem"]["name"]);
                        this.raiunoDidChange?.();
                    } else if (station["channel"] == ChannelLiveGuid.raidue) {
                        this.raidue.info = new NowPlaying(station["currentItem"]["name"], station["currentItem"]["timePublished"], station["nextItem"]["timePublished"], station["nextItem"]["name"]);
                        this.raidueDidChange?.();
                    } else if (station["channel"] == ChannelLiveGuid.raitre) {
                        this.raitre.info = new NowPlaying(station["currentItem"]["name"], station["currentItem"]["timePublished"], station["nextItem"]["timePublished"], station["nextItem"]["name"]);
                        this.raitreDidChange?.();
                    }
                }
            }
        });
        /// Load Mediaset Now Playing Data
        NetworkHelper("https://static3.mediasetplay.mediaset.it/apigw/nownext/R4.json", (json) => {
            let current_root = json["response"]["currentListing"]
            let current_title = current_root["mediasetlisting$epgTitle"];
            let current_startTime = current_root["startTime"];
            let current_endTime = current_root["endTime"];
            let next_title = json["response"]["nextListing"]["mediasetlisting$epgTitle"];
            /// Convert Timestamp to String like Rai
            let startDate = ("0" + new Date(current_startTime).getHours()).substr(-2) + ":" + ("0" + new Date(current_startTime).getMinutes()).substr(-2);
            let endDate = ("0" + new Date(current_endTime).getHours()).substr(-2) + ":" + ("0" + new Date(current_endTime).getMinutes()).substr(-2);
            
            if (current_title != "" && next_title != "") {
                this.retequattro.info = new NowPlaying(current_title, startDate, endDate, next_title);
                this.retequattroDidChange?.();
            }
        });
        NetworkHelper("https://static3.mediasetplay.mediaset.it/apigw/nownext/C5.json", (json) => {
            let current_root = json["response"]["currentListing"]
            let current_title = current_root["mediasetlisting$epgTitle"];
            let current_startTime = current_root["startTime"];
            let current_endTime = current_root["endTime"];
            let next_title = json["response"]["nextListing"]["mediasetlisting$epgTitle"];
            /// Convert Timestamp to String like Rai
            let startDate = ("0" + new Date(current_startTime).getHours()).substr(-2) + ":" + ("0" + new Date(current_startTime).getMinutes()).substr(-2);
            let endDate = ("0" + new Date(current_endTime).getHours()).substr(-2) + ":" + ("0" + new Date(current_endTime).getMinutes()).substr(-2);
            
            if (current_title != "" && next_title != "") {
                this.canalecinque.info = new NowPlaying(current_title, startDate, endDate, next_title);
                this.canalecinqueDidChange?.();
            }
        });
        NetworkHelper("https://static3.mediasetplay.mediaset.it/apigw/nownext/I1.json", (json) => {
            let current_root = json["response"]["currentListing"]
            let current_title = current_root["mediasetlisting$epgTitle"];
            let current_startTime = current_root["startTime"];
            let current_endTime = current_root["endTime"];
            let next_title = json["response"]["nextListing"]["mediasetlisting$epgTitle"];
            /// Convert Timestamp to String like Rai
            let startDate = ("0" + new Date(current_startTime).getHours()).substr(-2) + ":" + ("0" + new Date(current_startTime).getMinutes()).substr(-2);
            let endDate = ("0" + new Date(current_endTime).getHours()).substr(-2) + ":" + ("0" + new Date(current_endTime).getMinutes()).substr(-2);
            
            if (current_title != "" && next_title != "") {
                this.italiauno.info = new NowPlaying(current_title, startDate, endDate, next_title);
                this.italiaunoDidChange?.();
            }
        });
    }
}

function CreateVideoElement(src) {
    let player = document.createElement("video");
    player.preload = "metadata";
    player.src = src;
    let source = document.createElement("source");
    source.src = src;
    source.type = "application/x-mpegURL";
    player.appendChild(source);
    return player;
}
function CreateChannelElement(channel) {
    let channelViewer = document.createElement("div");
    channelViewer.id = "AGTVchannel";

    let channelName = document.createElement("div");
    channelName.innerText = channel.name;
    channelViewer.appendChild(channelName);

    let channelNumber = document.createElement("div");
    channelNumber.innerText = ChannelGuidToNumber(channel.id);
    channelViewer.appendChild(channelNumber);

    return channelViewer;
}
function GetCurrentTime() {
    return new Date().toLocaleTimeString('it-IT', { hour: '2-digit', minute: '2-digit' });
}
function CreateDateTimeElement() {
    let dateTime = document.createElement("div");
    dateTime.innerText = GetCurrentTime() + " " + new Date().toLocaleDateString('it-IT', { weekday: 'short', day: 'numeric', month: 'short' });
    return dateTime;
}
function CreateNowPlayingElement(current, next) {
    let nowPlayingViewer = document.createElement("div");
    nowPlayingViewer.id = "AGTVnowplaying";

    nowPlayingViewer.appendChild(CreateDateTimeElement());

    let nowPlayingCurrent = document.createElement("div");
    nowPlayingCurrent.innerText = current ?? "Nessuna informazione disponibile";
    nowPlayingViewer.appendChild(nowPlayingCurrent);

    let nowPlayingNext = document.createElement("div");
    nowPlayingNext.innerText = next ?? "";
    nowPlayingViewer.appendChild(nowPlayingNext);

    return nowPlayingViewer;
}
function CreatePauseIndicator() {
    let pauseIndicator = document.createElement("div");
    pauseIndicator.id = "AGTVpause";

    let pauseSymbol = document.createElement("div");
    pauseSymbol.innerText = "II";
    pauseIndicator.appendChild(pauseSymbol);

    return pauseIndicator;
}
function CreateScrubbingIndicators() {
    let scrubbingIndicators = document.createElement("div");
    scrubbingIndicators.id = "AGTVscrubbing";

    scrubbingIndicators.innerHTML += '<div id="AGTVprev"><div>&#x25B6;&#x25B6;</div></div>';
    scrubbingIndicators.innerHTML += '<div id="AGTVnext"><div>&#x25B6;&#x25B6;</div></div>';
    //scrubbingIndicators.innerHTML += '<div id="AGTVbeginning"><div>&#x25B6;&#x25B6;<span>I</span></div></div>';
    //scrubbingIndicators.innerHTML += '<div id="AGTVlive"><div>&#x25B6;&#x25B6;<span>I</span></div></div>';

    return scrubbingIndicators;
}
function CreateUserInterface(channel, current, next) {
    let userInterface = document.createElement("div");
    userInterface.id = "AGTVux";
    userInterface.appendChild(CreateChannelElement(channel));
    userInterface.appendChild(CreateNowPlayingElement(current, next));
    userInterface.appendChild(CreatePauseIndicator());
    userInterface.appendChild(CreateScrubbingIndicators());
    return userInterface;
}